/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_calloc.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rdanica <rdanica@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/19 13:00:44 by rdanica           #+#    #+#             */
/*   Updated: 2022/01/19 13:00:45 by rdanica          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_calloc(size_t count, size_t size)
{
	char	*mas;
	size_t	i;

	i = 0;
	mas = NULL;
	mas = malloc(size * count);
	if (!mas)
		return (NULL);
	while (i < (count * size))
	{
		mas[i] = 0;
		i++;
	}
	return ((void *)mas);
}
