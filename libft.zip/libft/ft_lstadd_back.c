/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstadd_back.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rdanica <rdanica@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/19 13:01:57 by rdanica           #+#    #+#             */
/*   Updated: 2022/01/19 13:01:57 by rdanica          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_lstadd_back(t_list **lst, t_list *new)
{
	t_list	*cell;

	if (new != NULL)
	{
		cell = *lst;
		if (cell == NULL)
			*lst = new;
		else
		{
			while (cell -> next != NULL)
				cell = cell -> next;
			cell -> next = new;
		}
	}
}
